module.exports = {
    theme: {
      extend: {
        screens: {
          'xs': '480px', // ya koi bhi value, sm se chhoti
        }
      }
    }
  }

  // tailwind.config.js
module.exports = {
  content: ["./**/*.html"], // ya apki file path
  theme: {
    extend: {
      fontFamily: {
        poppins: ['Poppins', 'sans-serif'],
      }
    }
  },
  plugins: [],
}


// tailwind.config.js
module.exports = {
  darkMode: 'class', // 👈 enable class-based dark mode
  content: ["./src/**/*.{html,js}"], // adjust to your file structure
  theme: {
    extend: {},
  },
  plugins: [],
}


